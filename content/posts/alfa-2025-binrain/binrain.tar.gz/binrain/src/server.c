#include "aes_server.h"

void generate_random_key(uint8_t *key) {
    FILE *urandom = fopen("/dev/urandom", "rb");
    if (! urandom) {
        printf("Error: Failed to open /dev/urandom\n");
        exit(1);
    }
    fread(key, 1, 16, urandom);
    fclose(urandom);
}

uint8_t FLAG[] = "alfa{XXXXXXXXXXXXXXXXXXXXXXXXXX}";
int FLAG_LEN = 32;

void hex_to_bytes(const char *hex_string, uint8_t *bytes) {
    for (size_t i = 0; i < strlen(hex_string) / 2; i++) {
        sscanf(hex_string + 2 * i, "%2hhx", &bytes[i]);
    }
}

void bytes_to_hex(const uint8_t *bytes, char *hex_string, int len) {
    for (int i = 0; i < len; i++) {
        sprintf(hex_string + 2 * i, "%02x", bytes[i]);
    }
    hex_string[len * 2] = '\0';
}

void send_encrypted_flag(const uint8_t *key) {
    data_t data;
    char hex_ciphertext[FLAG_LEN*2 + 1];

    for (int i = 0; i < FLAG_LEN; i += AES_BLOCKLEN) {
        memcpy(data.plaintext, FLAG + i, AES_BLOCKLEN);
        memcpy(data.ciphertext, data.plaintext, AES_BLOCKLEN);
        uint8_t * result = aes_encrypt_128(&data, key);
        bytes_to_hex(result, hex_ciphertext+i*2, AES_BLOCKLEN);
        free(result);
    }


    printf(
        "🌧️ ═══════════════════════════════════════════════════ 🌧️\n"
        "         WELCOME TO THE DIGITAL CAVE!\n"
        "🌧️ ═══════════════════════════════════════════════════ 🌧️\n\n"
        "⛈️  Suddenly the clouds thicken! A tropical rain of zeros\n"
        "   and ones is falling on you! Your beach umbrella can't\n"
        "   protect you from the digital downpour...\n\n"
        "🕳️  You found the entrance to a mysterious cave, but you\n"
        "   can't just walk in! The cave sent you a magical phrase,\n"
        "   but it's encrypted with the ancient AES-128 algorithm.\n\n"
        "✨ ENCRYPTED MAGICAL PHRASE: %s\n\n"
        "🔮 Decrypt it to find shelter from the digital rain!\n"
        "   The cave is ready to communicate with you...\n\n", hex_ciphertext);
}

void handle_interaction(last_encryption_t* last_encryption, const uint8_t* client_key) {
    char buffer[2048];
    char message[MAX_MESSAGE_LEN];
    int choice;
    data_t data;

    send_encrypted_flag(client_key);

    while (1) {
        printf(
            "🕳️ ═════════ VOICE OF THE CAVE ═════════ 🕳️\n"
            "  I hear your footsteps, traveler...\n"
            "  Say something, and I'll echo it back to you!\n\n"
            "🗣️  1. Say something to the cave (hear echo)\n"
            "📜 2. Read the last echo\n"
            "🚪 3. Leave the cave\n\n"
            "Choose your path (1-3): ");
        fflush(stdout);

        if (fgets(buffer, sizeof(buffer), stdin) == NULL) {
            break;
        }

        choice = atoi(buffer);

        switch (choice) {
            case MENU_AES128: {
                printf("🗣️ Say something to the cave: ");
                fflush(stdout);

                if (fgets(message, MAX_MESSAGE_LEN, stdin) == NULL) break;

                size_t recv_len = strlen(message);
                if (recv_len > 0 && message[recv_len - 1] == '\n') {
                    message[recv_len - 1] = '\0';
                    recv_len--;
                }
                if (recv_len % 16 != 0) {
                    for (size_t i = recv_len; i % 16 != 0; i++) {
                        message[i] = 0;
                        recv_len++;
                    }
                }

                if (last_encryption->has_data) {
                    free(last_encryption->last_ciphertext);
                    if (last_encryption->is_malloced) {
                        free(last_encryption->last_plaintext);
                    }
                }

                if (recv_len <= 16) {
                    memcpy(data.plaintext, message, AES_BLOCKLEN);
                    last_encryption->last_ciphertext = aes_encrypt_128(&data, client_key);
                    last_encryption->last_plaintext = (uint8_t *) &data.plaintext;
                    last_encryption->is_malloced = false;
                } else {
                    last_encryption->last_ciphertext = malloc(recv_len+1);

                    for (size_t i = 0; i < recv_len; i += 16) {
                        memcpy(data.plaintext, message + i, 16);
                        uint8_t * result = aes_encrypt_128(&data, client_key);
                        memcpy(last_encryption->last_ciphertext + i, result, 16);
                        free(result);
                    }

                    last_encryption->last_plaintext = malloc(recv_len+1);
                    memcpy(last_encryption->last_plaintext, message, recv_len);
                    last_encryption->is_malloced = true;
                }
                last_encryption->has_data = 1;
                last_encryption->ciphertext_len = recv_len;

                char * hex_result = malloc(recv_len*2 + 1);

                bytes_to_hex(last_encryption->last_ciphertext, hex_result, recv_len);
                printf(
                    "🕳️ The cave echoes back...\n"
                    "🗣️  You said: '%s'\n"
                    "🔊 Encrypted echo: %s\n"
                    "💭 Your words bounce off the cave walls\n"
                    "   and return as magical symbols...\n\n",
                    message, hex_result);
                free(hex_result);
                break;
            }

            case MENU_SHOW_LAST: {
                if (last_encryption->has_data) {
                    char * hex_result = malloc(last_encryption->ciphertext_len * 2 + 1);
                    bytes_to_hex(last_encryption->last_ciphertext, hex_result, last_encryption->ciphertext_len);
                    printf(
                        "📜 ═══════ LAST ECHO ═══════ 📜\n"
                        "🗣️   You said: '%s'\n"
                        "🔊  Encrypted echo: %s\n"
                        "💭  The echo still reverberates from the cave walls...\n\n",
                        last_encryption->last_plaintext,
                        hex_result);
                    free(hex_result);
                } else {
                    printf(
                        "📜 The echo in the cave has quieted...\n"
                        "   You haven't said anything yet.\n"
                        "   Say something to hear the echo!\n\n");
                }
                break;
            }

            case MENU_EXIT:
                printf(
                    "🚪 You leave the cave...\n"
                    "   The digital rain still falls outside.🌧️\n\n");
                return;

            default:
                printf(
                    "🕳️ The cave doesn't understand your words...\n"
                    "   Try choosing the right path (1-3).\n\n");
                break;
        }
    }
}

int main() {
    char buffer[32];
    uint8_t client_key[16];
    last_encryption_t last_encryption;
    
    if (getenv("MAGIC_WORD")) {
        printf("Say the magic word: ");
        fflush(stdout);
        if (fgets(buffer, sizeof(buffer) - 1, stdin) == NULL) {
            return 1;
        }
        buffer[strcspn(buffer, "\n")] = '\0';
        if (strcmp(buffer, getenv("MAGIC_WORD")) != 0) {
            printf("The magic did not happen.\n");
            return 1;
        }
        printf("The cave entrance opens up!\n");
    }
    
    if (getenv("FLAG") && strlen(getenv("FLAG")) == (size_t)FLAG_LEN) {
        memcpy(FLAG, getenv("FLAG"), FLAG_LEN);
    }

    generate_random_key(client_key);

    last_encryption.has_data = 0;
    last_encryption.last_plaintext = NULL;
    last_encryption.last_ciphertext = NULL;
    last_encryption.ciphertext_len = 0;

    handle_interaction(&last_encryption, client_key);

    if (last_encryption.has_data && last_encryption.last_ciphertext) {
        free(last_encryption.last_ciphertext);
        if (last_encryption.is_malloced && last_encryption.last_plaintext) {
            free(last_encryption.last_plaintext);
        }
    }

    return 0;
}
