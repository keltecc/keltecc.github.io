#ifndef AES_H
#define AES_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>

typedef uint8_t state_t[4][4];

typedef struct {
    uint8_t plaintext[16];
    uint8_t ciphertext[16]; 
} data_t;

#define AES_BLOCKLEN 16  
#define AES_keyExpSize 176

struct AES_ctx
{
  uint8_t RoundKey[AES_keyExpSize];
#if (defined(CBC) && (CBC == 1)) || (defined(CTR) && (CTR == 1))
  uint8_t Iv[AES_BLOCKLEN];
#endif
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);



uint8_t* AES_ECB_encrypt(const struct AES_ctx* ctx, state_t* buf);



uint8_t* aes_encrypt_128(data_t *data, const uint8_t *key);

#endif
