#ifndef AES_SERVER_H
#define AES_SERVER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <stdbool.h>
#include "aes.h"

#define MAX_MESSAGE_LEN 128

typedef struct {
    uint8_t* last_plaintext;
    uint8_t* last_ciphertext;
    bool is_malloced;
    int ciphertext_len;
    int has_data;
} last_encryption_t;

#define MENU_AES128 1
#define MENU_SHOW_LAST 2
#define MENU_EXIT 3

void handle_interaction(last_encryption_t* local_last_encryption, const uint8_t* client_key);
void send_encrypted_flag(const uint8_t *key);
void hex_to_bytes(const char *hex_string, uint8_t *bytes);
void bytes_to_hex(const uint8_t *bytes, char *hex_string, int len);

#endif
